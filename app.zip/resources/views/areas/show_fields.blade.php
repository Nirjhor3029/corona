<!-- District Name Field -->
<div class="form-group">
    {!! Form::label('district_name', 'District Name:') !!}
    <p>{{ $area->district_name }}</p>
</div>

