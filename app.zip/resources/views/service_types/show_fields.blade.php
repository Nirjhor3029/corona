<!-- Service Name Field -->
<div class="form-group">
    {!! Form::label('service_name', 'Service Name:') !!}
    <p>{{ $serviceType->service_name }}</p>
</div>

