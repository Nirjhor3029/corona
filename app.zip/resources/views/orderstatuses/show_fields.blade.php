<!-- Status Name Field -->
<div class="form-group">
    {!! Form::label('status_name', 'Status Name:') !!}
    <p>{{ $orderstatus->status_name }}</p>
</div>

