<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo e($supplier->name); ?></p>
</div>

<!-- Priority Field -->
<div class="form-group">
    <?php echo Form::label('priority', 'Priority:'); ?>

    <p><?php echo e($supplier->priority); ?></p>
</div>

<!-- Capacity Field -->
<div class="form-group">
    <?php echo Form::label('capacity', 'Capacity:'); ?>

    <p><?php echo e($supplier->capacity); ?></p>
</div>

<!-- User Id Field -->
<div class="form-group">
    <?php echo Form::label('user_id', 'User Id:'); ?>

    <p><?php echo e($supplier->user_id); ?></p>
</div>

<!-- Service Type Id Field -->
<div class="form-group">
    <?php echo Form::label('service_type_id', 'Service Type Id:'); ?>

    <p><?php echo e($supplier->service_type_id); ?></p>
</div>

<?php /**PATH C:\laragon\www\corona\resources\views/suppliers/show_fields.blade.php ENDPATH**/ ?>