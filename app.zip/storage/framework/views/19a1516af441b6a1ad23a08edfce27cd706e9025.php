<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Priority Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('priority', 'Priority:'); ?>

    <?php echo Form::number('priority', null, ['class' => 'form-control']); ?>

</div>

<!-- Capacity Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('capacity', 'Capacity:'); ?>

    <?php echo Form::number('capacity', null, ['class' => 'form-control']); ?>

</div>

<!-- User Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('user_id', 'User Id:'); ?>

    

    <?php if(isset($supplier->user->id)): ?>
    <select name="user_id" id="" class="form-control">
        <option value="<?php echo e(null); ?>" hidden>Select User</option>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>" <?php echo e(($user->id==$supplier->user->id)? "selected" : ""); ?>><?php echo e($user->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php else: ?>
    <select name="user_id" id="" class="form-control">
        <option value="<?php echo e(null); ?>" hidden>Select User</option>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>" ><?php echo e($user->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php endif; ?>
    
    
</div>

<!-- Service Type Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('service_type_id', 'Service Type Id:'); ?>

    
    <?php if(isset($supplier->service_type->id)): ?>
        <select name="service_type_id" id="" class="form-control">
            <option value="<?php echo e(null); ?>" hidden>Select Service type</option>
            <?php $__currentLoopData = $service_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($service_type->id); ?>" <?php echo e(($service_type->id==$supplier->service_type->id)? "selected" : ""); ?>><?php echo e($service_type->service_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <?php else: ?>
        <select name="service_type_id" id="" class="form-control">
            <option value="<?php echo e(null); ?>" hidden>Select Service type</option>
            <?php $__currentLoopData = $service_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($service_type->id); ?>" ><?php echo e($service_type->service_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <?php endif; ?>
    
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('suppliers.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\laragon\www\corona\resources\views/suppliers/fields.blade.php ENDPATH**/ ?>