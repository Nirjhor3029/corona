<div class="table-responsive">
    <table class="table" id="supplier_view_table">
        <thead>
            <tr>
                
                <th>Mobile</th>
                <th>Service Type</th>
                
                <th>Status</th>
                <th>Remarks</th>
                <th>Amount</th>
                <th>Update Time</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $class_name = "";
            if(strtolower($order->orderstatus->status_name) == "pending" )
            {
                $class_name = "pending";
            }elseif (strtolower($order->orderstatus->status_name) == "processing" ) {
                $class_name = "processing";
            }
            elseif (strtolower($order->orderstatus->status_name) == "delivered" ) {
                $class_name = "delivered";
            }elseif (strtolower($order->orderstatus->status_name) == "cancelled" ) {
                $class_name = "Cancelled";
            }else {
                $class_name = "cannot_delivered";
            }
        ?>
        <?php echo Form::open(['route' => ['supplier.update_status', $order->id], 'method' => 'post']); ?>

            <tr>
                
                <td><?php echo e($order->mobile); ?></td>
                <td><?php echo e($order->service_type->service_name); ?></td>
                
                <td class="<?php echo e($class_name); ?>">
                    
                    <?php echo e($order->orderstatus->status_name); ?>

                </td>
                <td>
                    

                    <?php echo e($order->remarks); ?>

                </td>
                <td>
                    
                    <?php echo e($order->amount); ?>

                </td>
                <td><?php echo e(date_format($order->updated_at,"M d, Y")); ?></td>
                
            </tr>
            <?php echo Form::close(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <script>
        function checkStatus(ev,orderId) {

            let btn = document.getElementById("btn_submit"+orderId);
            let order_amount = document.getElementById("order_amount"+orderId);

            let value = ev.value;
            let text = ev.options[ev.selectedIndex].text;
            console.log(text.toLowerCase());
            
            if(text.toLowerCase() == "processing"){
                order_amount.disabled = true;
                order_amount.required = false;
                btn.disabled = false;
            }else if(text.toLowerCase() == "delivered"){
                order_amount.disabled = false;
                order_amount.required = true;
                btn.disabled = false;
            }
            else if(text.toLowerCase() == "pending"){
                order_amount.disabled = true;
                order_amount.required = false;
                btn.disabled = false;
            }
            else if(text.toLowerCase() == "cancelled"){
                order_amount.disabled = true;
                order_amount.required = false;
                btn.disabled = false;
            }else{
                //Can't delivered
                // alert('cant');
                order_amount.disabled = true;
                order_amount.required = false;
                btn.disabled = false;
            }
            
        } 
            
    </script>
</div>
<?php /**PATH C:\laragon\www\corona\resources\views/supplier_views/suppliers/table_summery.blade.php ENDPATH**/ ?>