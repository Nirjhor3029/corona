<!-- Service Name Field -->
<div class="form-group">
    <?php echo Form::label('service_name', 'Service Name:'); ?>

    <p><?php echo e($serviceType->service_name); ?></p>
</div>

<?php /**PATH C:\laragon\www\corona\resources\views/service_types/show_fields.blade.php ENDPATH**/ ?>