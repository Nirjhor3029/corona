<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo e($order->name); ?></p>
</div>

<!-- Mobile Field -->
<div class="form-group">
    <?php echo Form::label('mobile', 'Mobile:'); ?>

    <p><?php echo e($order->mobile); ?></p>
</div>

<!-- Service Type Id Field -->
<div class="form-group">
    <?php echo Form::label('service_type_id', 'Service Type Id:'); ?>

    <p><?php echo e($order->service_type_id); ?></p>
</div>

<!-- Supllier Id Field -->
<div class="form-group">
    <?php echo Form::label('supllier_id', 'Supllier Id:'); ?>

    <p><?php echo e($order->supllier_id); ?></p>
</div>

<!-- Orderstatus Id Field -->
<div class="form-group">
    <?php echo Form::label('orderstatus_id', 'Orderstatus Id:'); ?>

    <p><?php echo e($order->orderstatus_id); ?></p>
</div>

<!-- Remarks Field -->
<div class="form-group">
    <?php echo Form::label('remarks', 'Remarks:'); ?>

    <p><?php echo e($order->remarks); ?></p>
</div>

<!-- Amount Field -->
<div class="form-group">
    <?php echo Form::label('amount', 'Amount:'); ?>

    <p><?php echo e($order->amount); ?></p>
</div>

<!-- Date Time Field -->
<div class="form-group">
    <?php echo Form::label('date_time', 'Date Time:'); ?>

    <p><?php echo e($order->date_time); ?></p>
</div>

<?php /**PATH C:\laragon\www\corona\resources\views/orders/show_fields.blade.php ENDPATH**/ ?>