<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Mobile Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('mobile', 'Mobile:'); ?>

    <?php echo Form::text('mobile', null, ['class' => 'form-control']); ?>

</div>

<!-- Service Type Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('service_type', 'Service Type:'); ?>

    <?php echo Form::text('service_type', null, ['class' => 'form-control']); ?>

</div>

<!-- Living Area Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('living_area', 'Living Area:'); ?>

    <?php echo Form::text('living_area', null, ['class' => 'form-control']); ?>

</div>

<!-- Date Time Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('date_time', 'Date Time:'); ?>

    <?php echo Form::text('date_time', null, ['class' => 'form-control','id'=>'date_time']); ?>

</div>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $('#date_time').datetimepicker({
            format: 'YYYY-MM-DD HH:mm:ss',
            useCurrent: true,
            sideBySide: true
        })
    </script>
<?php $__env->stopPush(); ?>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('data.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\laragon\www\corona\resources\views/data/fields.blade.php ENDPATH**/ ?>