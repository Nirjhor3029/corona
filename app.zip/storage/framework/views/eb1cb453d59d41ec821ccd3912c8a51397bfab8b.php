<aside class="main-sidebar nav_left_bar_background" id="sidebar-wrapper" >

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(asset('/images/user.jpg')); ?>" class="img-circle"
                        alt="User Image"/>
            </div>
            <div class="pull-left info">
                <?php if(Auth::guest()): ?>
                <p><?php echo e(config('app.dev_com')); ?></p>
                <?php else: ?>
                    <p><?php echo e(Auth::user()->name); ?></p>
                <?php endif; ?>
                <!-- Status -->
                <a href="#">
                    <i class="fa fa-circle text-success"></i> 
                    <?php echo e((Auth::user()->role == 0)? "Supplier" : "Admin"); ?>

                </a>
            </div>
        </div>

        <!-- search form (Optional) -->
        
        <!-- Sidebar Menu -->

        <hr>
        <ul class="sidebar-menu" data-widget="tree">
            <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </ul>
        <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside><?php /**PATH C:\laragon\www\corona\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>