<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo e($data->name); ?></p>
</div>

<!-- Mobile Field -->
<div class="form-group">
    <?php echo Form::label('mobile', 'Mobile:'); ?>

    <p><?php echo e($data->mobile); ?></p>
</div>

<!-- Service Type Field -->
<div class="form-group">
    <?php echo Form::label('service_type', 'Service Type:'); ?>

    <p><?php echo e($data->service_type); ?></p>
</div>

<!-- Living Area Field -->
<div class="form-group">
    <?php echo Form::label('living_area', 'Living Area:'); ?>

    <p><?php echo e($data->living_area); ?></p>
</div>

<!-- Date Time Field -->
<div class="form-group">
    <?php echo Form::label('date_time', 'Date Time:'); ?>

    <p><?php echo e($data->date_time); ?></p>
</div>

<?php /**PATH C:\laragon\www\corona\resources\views/data/show_fields.blade.php ENDPATH**/ ?>