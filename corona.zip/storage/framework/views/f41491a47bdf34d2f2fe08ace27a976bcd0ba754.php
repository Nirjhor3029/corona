<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', $supplier->name, ['class' => 'form-control']); ?>

</div>


<div class="form-group col-sm-6">
    <?php echo Form::label('capacity', 'Capacity:'); ?>

    <?php echo Form::number('capacity', $supplier->capacity, ['class' => 'form-control']); ?>

</div>



<div class="form-group col-sm-6">
    <?php echo Form::label('service_type_id', 'Service Type Id:'); ?>

    
    <select name="service_type_id" id="" class="form-control">
        <option value="<?php echo e(null); ?>" hidden>Select Service type</option>
        <?php $__currentLoopData = $service_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($service_type->id); ?>" <?php echo e(($supplier->service_type_id==$service_type->id)? "selected" : ""); ?>><?php echo e($service_type->service_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Update', ['class' => 'btn btn-primary']); ?>

    
</div>
<?php /**PATH C:\laragon\www\corona\resources\views/supplier_views/suppliers/fields.blade.php ENDPATH**/ ?>