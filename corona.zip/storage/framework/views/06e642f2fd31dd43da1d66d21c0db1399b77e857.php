<!-- District Name Field -->
<div class="form-group">
    <?php echo Form::label('district_name', 'District Name:'); ?>

    <p><?php echo e($area->district_name); ?></p>
</div>

<?php /**PATH C:\laragon\www\corona\resources\views/areas/show_fields.blade.php ENDPATH**/ ?>