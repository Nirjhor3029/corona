

<?php if(\Illuminate\Support\Facades\Auth::user()->role == "admin"): ?>






<li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-edit"></i><span>Users</span></a>
</li>

<li class="<?php echo e(Request::is('suppliers*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('suppliers.index')); ?>"><i class="fa fa-edit"></i><span>Suppliers</span></a>
</li>

<li class="<?php echo e(Request::is('serviceTypes*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('serviceTypes.index')); ?>"><i class="fa fa-edit"></i><span>Service Types</span></a>
</li>

<li class="<?php echo e(Request::is('orderstatuses*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('orderstatuses.index')); ?>"><i class="fa fa-edit"></i><span>Orderstatuses</span></a>
</li>

<li class="<?php echo e(Request::is('import*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('import_csv')); ?>"><i class="fa fa-edit"></i><span>Import Data</span></a>
</li>
<li class="<?php echo e(Request::is('data*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('data.index')); ?>"><i class="fa fa-edit"></i><span>Data</span></a>
</li>

<li class="<?php echo e(Request::is('orders*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('orders.index')); ?>"><i class="fa fa-edit"></i><span>Orders</span></a>
</li>


    
<?php else: ?>
<li class="<?php echo e(Request::is('dashboard*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('supplier.dashboard2')); ?>"><i class="fa fa-dashboard"></i><span>Dashboard</span></a>
</li>
<li class="<?php echo e(Request::is('dashboard*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('supplier.dashboard')); ?>"><i class="fa fa-gear"></i><span>Settings</span></a>
</li>
<li class="<?php echo e(Request::is('dashboard*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('supplier.orders')); ?>"><i class="fa fa-edit "></i><span>Orders</span></a>
</li>
<?php endif; ?>



<?php /**PATH C:\laragon\www\corona\resources\views/layouts/menu.blade.php ENDPATH**/ ?>