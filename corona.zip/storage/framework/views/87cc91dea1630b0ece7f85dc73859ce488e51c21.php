<div class="table-responsive">
    <table class="table" id="orders-table">
        <thead>
            <tr>
                
                <th>Mobile</th>
                <th>Service Type </th>
                <th>supplier</th>
                <th>Status </th>
                <th>Remarks</th>
                <th>Amount</th>
                <th>Update Time</th>
                <th >Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <tr>
                
                <td><?php echo e($order->mobile); ?></td>
                <td><?php echo e($order->service_type->service_name); ?></td>
                <td><?php echo e($order->supplier['name']); ?></td>
                
                <td><?php echo e($order->orderstatus->status_name); ?></td>
                <td><?php echo e($order->remarks); ?></td>
                <td><?php echo e($order->amount); ?></td>
                <td><?php echo e($order->updated_at); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['orders.destroy', $order->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('orders.show', [$order->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('orders.edit', [$order->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\laragon\www\corona\resources\views/orders/table.blade.php ENDPATH**/ ?>