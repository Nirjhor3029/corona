<!-- Name Field -->

<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Mobile Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('mobile', 'Mobile:'); ?>

    <?php echo Form::text('mobile', null, ['class' => 'form-control']); ?>

</div>

<!-- Service Type Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('service_type_id', 'Service Type Id:'); ?>

    <select name="service_type_id" id="" class="form-control">
        <option value="<?php echo e(null); ?>" hidden>Select Service type</option>
        <?php $__currentLoopData = $service_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option  value="<?php echo e($service_type->id); ?>" <?php echo e(( $order->service_type->id == $service_type->id ) ? "selected" : ""); ?> ><?php echo e($service_type->service_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<!-- Supllier Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('supllier_id', 'Supllier Id:'); ?>


    

    <select name="supllier_id" id="" class="form-control">
        <option value="<?php echo e(null); ?>" hidden>Select Supplier</option>
        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option  value="<?php echo e($supplier->id); ?>" <?php echo e(( $order->supplier->id == $supplier->id ) ? "selected" : ""); ?> ><?php echo e($supplier->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<!-- Orderstatus Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('orderstatus_id', 'Orderstatus Id:'); ?>

    
    
    <select name="orderstatus_id" id="" class="form-control">
        <option value="<?php echo e(null); ?>" hidden>Select Status</option>
        <?php $__currentLoopData = $order_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderstatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option  value="<?php echo e($orderstatus->id); ?>" <?php echo e(( $order->orderstatus->id == $orderstatus->id ) ? "selected" : ""); ?> ><?php echo e($orderstatus->status_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<!-- Remarks Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('remarks', 'Remarks:'); ?>

    <?php echo Form::text('remarks', null, ['class' => 'form-control']); ?>

</div>

<!-- Amount Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('amount', 'Amount:'); ?>

    <?php echo Form::number('amount', null, ['class' => 'form-control']); ?>

</div>

<!-- Date Time Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('date_time', 'Date Time:'); ?>

    <?php echo Form::text('date_time', null, ['class' => 'form-control','id'=>'date_time']); ?>

</div>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $('#date_time').datetimepicker({
            format: 'YYYY-MM-DD HH:mm:ss',
            useCurrent: true,
            sideBySide: true
        })
    </script>
<?php $__env->stopPush(); ?>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH C:\laragon\www\corona\resources\views/orders/fields.blade.php ENDPATH**/ ?>