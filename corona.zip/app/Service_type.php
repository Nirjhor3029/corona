<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Service_type extends Model
{
    //
}
